Main user GUI: 'IntegratedFrontPanelArduinoMotor' 
